package com.cg.mobilebilling.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.mobilebilling.beans.Customer;

@Controller
public class URIController {
	Customer customer;
	@RequestMapping("/")
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/registerCustomer")
	public String getRegisterCustomer() {
		return "registerCustomerPage";
	}
	@ModelAttribute
	public Customer getCustomer() {
		customer=new Customer();
		return customer;
	}
	@RequestMapping("/openPostPaid")
	public String openPostPaidAccount() {
		return "openPostPaidPage";
	}
	@RequestMapping("/getCustomer")
	public String getCustomerDetails() {
		return "getCustomerPage";
	}
	@RequestMapping("/getPostPaid")
	public String getPostPaid() {
		return "getPostPaidPage";
	}
	@RequestMapping("/getAllPostPaid")
	public String getAllPostPaid() {
		return "getAllPostPaidPage";
	}
	@RequestMapping("/getPlan")
	public String getPlan() {
		return "getPlanPage";
	}
	@RequestMapping("/deleteCustomer")
	public String deleteCustomer() {
		return "deleteCustomerPage";
	}
	@RequestMapping("/closePostPaid")
	public String closePostPaid() {
		return "closePostPaidPage";
	}
	@RequestMapping("/changePlan")
	public String changePlan() {
		return "changePlanPage";
	}
	@RequestMapping("/getAllBill")
	public String getAllBill() {
		return "getAllBillPage";
	}
	@RequestMapping("/getMobileBill")
	public String getMobileBill() {
		return "getMobileBillPage";
	}
	@RequestMapping("/generateBill")
	public String generateBill() {
		return "generateBillPage";
	}
}
