package com.cg.project.beans;

public class Associate {
	private int associateId;
 	private String password,firstName,lastName,phoneNo,email,date,setPassword,confirmPassword;
 	private String hobbies[];
	public Associate() {}
	
	public Associate(int associateId, String password) {
		super();
		this.associateId = associateId;
		this.password = password;
	}


	public Associate(String firstName, String lastName,
			String phoneNo, String email, String setPassword,
			String confirmPassword, String[] hobbies) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNo = phoneNo;
		this.email = email;
		this.setPassword = setPassword;
		this.confirmPassword = confirmPassword;
		this.hobbies = hobbies;
	}

	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getSetPassword() {
		return setPassword;
	}

	public void setSetPassword(String setPassword) {
		this.setPassword = setPassword;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String[] getHobbies() {
		return hobbies;
	}

	public void setHobbies(String[] hobbies) {
		this.hobbies = hobbies;
	}

	@Override
	public String toString() {
		return "Associate [associateID=" + associateId + ", password="
				+ password + "]";
	}
 
}
