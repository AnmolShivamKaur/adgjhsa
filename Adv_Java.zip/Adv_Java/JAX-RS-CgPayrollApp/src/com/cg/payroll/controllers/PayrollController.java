package com.cg.payroll.controllers;

public class PayrollController {

}
