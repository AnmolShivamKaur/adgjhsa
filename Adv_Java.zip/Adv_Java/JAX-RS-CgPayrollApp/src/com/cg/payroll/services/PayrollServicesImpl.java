package com.cg.payroll.services;
import java.util.ArrayList;
import com.cg.payroll.beans.*;

import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.*;
;
public class PayrollServicesImpl implements PayrollServices{
	private AssociateDAO associateDAO = new AssociateDAOImpl();

	@Override
	public int acceptAssociateDetails(String firstName, String lastName,
			String emailId, String department, String designation,
			String pancard, int yearlyInvestmentUnder8oC, int basicSalary,
			int epf, int companyPf, int accountNumber, String bankName,
			String ifscCode) throws PayrollServicesDownException {
			Associate associate=new Associate(yearlyInvestmentUnder8oC,firstName, lastName,department, designation, pancard, emailId, 
					new BankDetails(accountNumber, bankName, ifscCode), new Salary(basicSalary, epf, companyPf));
			associate=associateDAO.save(associate);
			return associate.getAssociateId();

	}

	@Override
	public int calculateNetSalary(int associateId)
			throws AssociateDetailNotFoundException,
			PayrollServicesDownException {
		Associate associate = getAssociateDetails(associateId);
		associate.getSalary().setHra((30*associate.getSalary().getBasicSalary())/100);
		associate.getSalary().setPersonalAllowance((20*associate.getSalary().getBasicSalary())/100);
		associate.getSalary().setOtherAllowance((20*associate.getSalary().getBasicSalary())/100);
		associate.getSalary().setConveyanceAllowance((10*associate.getSalary().getBasicSalary())/100);
		associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().
				getConveyanceAllowance()+associate.getSalary().getHra()+associate.getSalary().getOtherAllowance()+associate.getSalary().getPersonalAllowance());
		if(associate.getSalary().getGrossSalary()*12>0&&associate.getSalary().getGrossSalary()*12<250000)
			associate.getSalary().setMonthlyTax(0);
		else if(associate.getSalary().getGrossSalary()*12>250000&&associate.getSalary().getGrossSalary()*12<500000)
			associate.getSalary().setMonthlyTax((((associate.getSalary().getGrossSalary()*12)-250000)*5)/(100*12));
		else if(associate.getSalary().getGrossSalary()*12>500000&&associate.getSalary().getGrossSalary()*12<1000000)
			associate.getSalary().setMonthlyTax((250000*5)/(100*12)+(((associate.getSalary().getGrossSalary()*12)-500000)*20)/(100*12));
		else if(associate.getSalary().getGrossSalary()*12>1000000)
			associate.getSalary().setMonthlyTax((250000*5)/(100*12)+
					(500000*20)/(100*12)+(((associate.getSalary().getGrossSalary()*12)-1000000)*30)/(100*12));
		associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax());
			associateDAO.update(associate);
		return associate.getSalary().getNetSalary(); 

	}

	@Override
	public Associate getAssociateDetails(int associateId)
			throws AssociateDetailNotFoundException,
			PayrollServicesDownException {
		Associate associate = associateDAO.findOne(associateId);
		if(associate==null) throw new AssociateDetailNotFoundException("Associate Details Not Found");
		return associate;

	}
	@Override
	public ArrayList<Associate> getAllAssociateDetails()
			throws PayrollServicesDownException {
			return associateDAO.findAll();

	}

}
